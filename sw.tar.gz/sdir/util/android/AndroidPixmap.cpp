//
// Copyright 2016 The ANGLE Project Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
//

// AndroidPixmap.cpp: Implementation of OSPixmap for Android

#include "util/OSPixmap.h"

OSPixmap *CreateOSPixmap()
{
    return nullptr;
}
